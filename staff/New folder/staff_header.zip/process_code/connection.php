<?php
  $localhost= "localhost";
  $username= "root";
  $password= "";
  $dbname= "crm_gfi";

  $connection = mysqli_connect($localhost,$username,$password,$dbname);

  //if($connection){
   // echo"connected";
//}else{
 //   echo "disconnected";
//}
?>
